package com.training.mongoDb.controller;

import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.mongoDb.model.users;
import com.training.mongoDb.service.userService;


@RestController
@RequestMapping(value= "/emp")
public class userController {
	

 
    @Autowired
    userService serv;
 
 
    @PostMapping(value= "/create")
    public String create(@RequestBody java.util.List<users> emp) {     
        serv.createUser(emp);
        return "Employee records created.";
    }
    
    @GetMapping(value= "/getall")
    public Collection<users> getAll() {
        return serv.getAllEmployees();
    }
 

     
    @PutMapping(value= "/update/{employee-id}")
    public String update(@PathVariable(value= "employee-id") int id, @RequestBody users e) {
        e.setEmp_id(id);
        serv.updateEmployee(e);
        return "Employee record for employee-id= " + id + " updated.";
    }
 
 
    @DeleteMapping(value= "/deleteall")
    public String deleteAll() {
        serv.deleteAllEmployees();
        return "All employee records deleted.";
    }
}