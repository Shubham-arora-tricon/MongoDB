package com.training.mongoDb.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.mongoDb.model.users;
import com.training.mongoDb.repository.userRepository;

@Service
public class userService {
	@Autowired
	userRepository dao;
	
	public void createUser(List<users> emp) {
        dao.saveAll(emp);
    }
	
    public Collection<users> getAllEmployees() {
        return dao.findAll();
    }
 
 
    public void updateEmployee(users emp) {
        dao.save(emp);
    }
 
    
    public void deleteAllEmployees() {
        dao.deleteAll();
    }
	

	
}
