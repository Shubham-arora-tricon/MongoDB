package com.training.mongoDb.model;

import java.math.BigInteger;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "tusers")
public class users {
	
	//Employee Id, Name, Departments, Reporting Manager, Age, Salary
	
	@Id
	private int emp_id;
	private String name;
	private String departments;
	private String reporting_Manager;
	private int age;
	private BigInteger salary;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartments() {
		return departments;
	}
	public void setDepartments(String departments) {
		this.departments = departments;
	}
	public String getReporting_Manager() {
		return reporting_Manager;
	}
	public void setReporting_Manager(String reporting_Manager) {
		this.reporting_Manager = reporting_Manager;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public BigInteger getSalary() {
		return salary;
	}
	public void setSalary(BigInteger salary) {
		this.salary = salary;
	}
	public users(int emp_id, String name, String departments, String reporting_Manager, int age, BigInteger salary) {
		super();
		this.emp_id = emp_id;
		this.name = name;
		this.departments = departments;
		this.reporting_Manager = reporting_Manager;
		this.age = age;
		this.salary = salary;
	}
}
